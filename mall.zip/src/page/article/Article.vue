<template>
    <div class="find">
        <div class="Latest">{{article}}</div>
        <el-row>
            <el-col :span="8"></el-col>
            <el-col :span="16"></el-col>
        </el-row>
    </div>
</template>

<script>
export default {
  name: "Article",
  data(){
      return{
          article:'精选文章',
          articleinfo:[
              {img:'',title:'',suffix:''}
          ]
      }
  }
};
</script>

<style scoped lang="scss">

</style>